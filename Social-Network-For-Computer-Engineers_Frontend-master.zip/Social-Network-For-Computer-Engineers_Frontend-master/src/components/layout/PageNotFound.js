import React, {Fragment} from 'react';

const PageNotFound = () => {
    return (
        <Fragment>
          <section className='container'>
          <h2 >404 Page not found</h2>
          <br/>
          </section>
        </Fragment>
      );
    };

export default PageNotFound;