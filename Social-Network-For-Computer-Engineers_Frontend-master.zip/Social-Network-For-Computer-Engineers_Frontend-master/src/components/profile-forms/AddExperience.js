import React, { useState } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Link, useNavigate } from 'react-router-dom';
import { addExperience } from '../../actions/profile';
import Alert from '../layout/Alert';

const AddExperience = ({ addExperience }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    company: '',
    title: '',
    location: '',
    from: '',
    to: '',
    current: false,
    description: '',
  });

  const [toDateDisabled, toggleDisabled] = useState(false);

  const { company, title, location, from, to, current, description } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  return (
    <section className='container'>
      <Alert />
      <h1 className='large text-primary'>Add Experience</h1>
      <p>* Required field</p>
      <form
        className='form'
        onSubmit={(e) => {
          e.preventDefault();
          addExperience(formData, navigate);
        }}
      >
        <small className='form-text smaller'>
          * Title
        </small>
        <div className='form-group'>
          <input
            type='text'
            placeholder='eg. Developer'
            name='title'
            value={title}
            onChange={(e) => onChange(e)}
            required
          />
        </div>
        <small className='form-text smaller'>
          * Company
        </small>
        <div className='form-group'>
          <input
            type='text'
            name='company'
            value={company}
            onChange={(e) => onChange(e)}
            required
          />
        </div>
        <small className='form-text smaller'>
          Location
        </small>
        <div className='form-group'>
          <input
            type='text'
            name='location'
            value={location}
            onChange={(e) => onChange(e)}
          />
        </div>
        <small className='form-text smaller'>
          Start Date
        </small>
        <div className='form-group'>
          <input
            type='date'
            name='from'
            value={from}
            onChange={(e) => onChange(e)}
          />
        </div>
        <div className='form-group'>
          <p>
            <input
              type='checkbox'
              name='current'
              checked={current}
              value={current}
              onChange={(e) => {
                setFormData({ ...formData, current: !current });
                toggleDisabled(!toDateDisabled);
              }}
            />
            {''} Current Job
          </p>
        </div>
        <small className='form-text smaller'>
          End Date
        </small>
        <div className='form-group'>
          <input
            type='date'
            name='to'
            value={to}
            onChange={(e) => onChange(e)}
            disabled={toDateDisabled ? 'disabled' : ''}
          />
        </div>
        <small className='form-text smaller'>
          Description
        </small>
        <div className='form-group'>
          <textarea
            name='description'
            cols='30'
            rows='5'
            value={description}
            onChange={(e) => onChange(e)}
          ></textarea>
        </div>
        <input type='submit' className='btn btn-primary my-1' value='Submit' />
        <Link to='/dashboard' className='btn btn-light my-1'>
          Go Back
        </Link>
      </form>
    </section>
  );
};
AddExperience.propTypes = {
  addExperience: PropTypes.func.isRequired,
};

export default connect(null, { addExperience })(AddExperience);
