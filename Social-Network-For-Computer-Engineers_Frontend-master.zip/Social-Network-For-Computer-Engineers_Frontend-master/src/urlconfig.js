export const api =
  'http://socialnetworknodeapp-env.eba-abwp5m5n.us-east-1.elasticbeanstalk.com/api';

export const YOUTUBE_API_KEY = 'AIzaSyCugo0z6gqr89-sLOuD5Okhyj6aJRtJbvU';
